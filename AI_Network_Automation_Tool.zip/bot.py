import socket
import os
import re
import json
import time
import asyncio
import requests
from dotenv import load_dotenv

from telegram import Update
from telegram.ext import Application, MessageHandler, CommandHandler, ContextTypes, filters
from datetime import datetime, timedelta
from netmiko import ConnectHandler


from concurrent.futures import ThreadPoolExecutor


# force IPv4
def force_ipv4():
    orig_getaddrinfo = socket.getaddrinfo

    def new_getaddrinfo(*args, **kwargs):
        return [info for info in orig_getaddrinfo(*args, **kwargs) if info[0] == socket.AF_INET]

    socket.getaddrinfo = new_getaddrinfo

force_ipv4()
EXECUTOR = ThreadPoolExecutor(max_workers=8)
DEBUG_ZBX = False
ZBX_ITEM_CACHE = {}
ZBX_7D_CACHE = {}

async def run_blocking(func, *args):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(EXECUTOR, func, *args)

async def resolve_both(a_query, b_query):
    return await asyncio.gather(
        run_blocking(zbx_resolve_device, a_query),
        run_blocking(zbx_resolve_device, b_query),
    )

async def connect_both(A, B):
    return await asyncio.gather(
        run_blocking(connect_device, A),
        run_blocking(connect_device, B),
    )

async def get_desc_both(connA, kwA, devA, connB, kwB, devB):
    return await asyncio.gather(
        run_blocking(get_int_descriptions, connA, kwA, devA),
        run_blocking(get_int_descriptions, connB, kwB, devB),
    )

async def zbx_both(A, a_intf, B, b_intf_real):
    return await asyncio.gather(
        run_blocking(zbx_port_power_7d, A, a_intf),
        run_blocking(zbx_port_power_7d, B, b_intf_real),
    )


# ===================== ENV =====================
load_dotenv()

TG_TOKEN   = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
ZBX_URL    = os.getenv("ZABBIX_URL", "").strip()
ZBX_TOKEN  = os.getenv("ZABBIX_TOKEN", "").strip()

SSH_USER   = os.getenv("SSH_USER", "").strip()
SSH_PASS   = os.getenv("SSH_PASS", "").strip()
SSH_PORT   = int(os.getenv("SSH_PORT", "22").strip())

OS_CACHE_FILE = os.getenv("OS_CACHE_FILE", "os_type_cache.json").strip()

if not TG_TOKEN:
    raise SystemExit("Missing TELEGRAM_BOT_TOKEN in .env")
if not ZBX_URL.startswith("http"):
    raise SystemExit("Missing/invalid ZABBIX_URL in .env (must start with http/https)")
if not ZBX_TOKEN:
    raise SystemExit("Missing ZABBIX_TOKEN in .env")
if not SSH_USER or not SSH_PASS:
    raise SystemExit("Missing SSH_USER / SSH_PASS in .env")


AI_ENABLED = True  # خليها False إذا ما تريد AI نهائياً

def build_health_flags():
    return {
        "all_green": True,

        # Counters
        "rx_warn": 0,
        "rx_crit": 0,
        "rx_na": 0,
        "crc": 0,
        "ping_bad": 0,

        # Optional text lists
        "warn": [],
        "crit": [],
        "info": []
    }

def mark_info(h, reason: str):
    h["info"].append(reason)
def mark_warn(h, reason: str):
    h["all_green"] = False
    h["warn"].append(reason)
def flag_rx(val, health_flags):
    if val is None:
        health_flags["rx_na"] += 1
        return
    if val <= -39:
        health_flags["rx_crit"] += 1
    elif val < -15:
        health_flags["rx_warn"] += 1
    elif val < -13:   # <-- هذا اللي انت تريده
        health_flags["rx_warn"] += 1
def decision_text_rule_based(h):
    if h["rx_crit"] > 0 or h["crc"] > 0 or h["ping_bad"] > 0:
        return "🚨 اسأل قيم النوك — مشكلة واضحة."

    if h["rx_warn"] > 0:
        return "⚠️ اسأل قيم النوك — RX ضمن Warning."

    if h["rx_na"] > 0:
        return "⚠️ اسأل قيم النوك — RX/TX غير متاح."

    return "✅  done"


def mark_crit(h, reason: str):
    h["all_green"] = False
    h["crit"].append(reason)

#def decision_text_rule_based(health):
 #   if health["all_green"]:
 #       return "✅ AI Decision:  done — كلشي Green."
 #   if health["crit"]:
 #       return "🟥 AI Decision: اسأل قيم النوك — " + "; ".join(health["crit"][:5])
 #   if health["warn"]:
 #       return "🟨 AI Decision: اسأل قيم النوك — " + "; ".join(health["warn"][:5])
    # فقط INFO (مثل RX/TX NA) بدون warn/crit
  #  return "✅ AI Decision: Sudden done — Ping/CRC OK (RX/TX NA Info)."

# --- Optional OpenAI (إذا تريد) ---
def analyze_with_ai(summary_text: str, health: dict):
    """
    يرجع نص قصير. إذا ماكو API Key أو AI_DISABLED يرجع rule-based.
    """
    if not AI_ENABLED:
        return decision_text_rule_based(health)

    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        return decision_text_rule_based(health)

    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

        prompt = f"""
أنت مساعد NOC. هذا تقرير Link بين جهازين.
أريد قرار نهائي بسطر واحد:
- إذا كلشي Green: اكتب " done ✅"
- إذا Warning/Critical: اكتب "اسأل قسم النوك ⚠️" + سبب مختصر جداً.

Health JSON:
{json.dumps(health, ensure_ascii=False)}

Report:
{summary_text}

رجاءً: جواب سطر واحد فقط.
"""

        r = client.responses.create(
            model=model,
            input=prompt
        )
        out = (r.output_text or "").strip()
        return out if out else decision_text_rule_based(health)

    except Exception:
        return decision_text_rule_based(health)


def section_block(title: str):
    # ستايل بسيط للقسم
    return [
        "",
        "═" * 24,
        title,
        "═" * 24,
    ]

# ===================== HOST/IP FILTER =====================
HOST_RE = re.compile(
    r"^(?:"
    r"\d{1,3}(?:\.\d{1,3}){3}"          # IP
    r"|"
    r"[A-Za-z0-9][A-Za-z0-9\-]{2,}"     # Hostname
    r")$"
)

def is_valid_host(x: str) -> bool:
    if not x:
        return False
    if not HOST_RE.match(x):
        return False
    # only ASCII (prevent "هلو عمار")
    if re.search(r"[^\x00-\x7F]", x):
        return False
    return True


# ===================== ZABBIX API =====================
def zbx_call(method: str, params: dict):
    payload = {"jsonrpc":"2.0","method":method,"params":params,"id":1}
    headers = {
        "Content-Type":"application/json-rpc",
        "Authorization": f"Bearer {ZBX_TOKEN}",
    }
    r = requests.post(ZBX_URL, json=payload, headers=headers, timeout=25)
    r.raise_for_status()
    data = r.json()
    if "error" in data:
        raise RuntimeError(f"Zabbix API error: {data['error']}")
    return data.get("result")


def looks_like_ip(s: str) -> bool:
    return bool(re.match(r"^\d{1,3}(?:\.\d{1,3}){3}$", s.strip()))
def base_host_name(name: str) -> str:
    if not name:
        return name
    suffixes = ["-TTM", "-Test", "-S816", "-TEST", "-test"]
    out = name
    for s in suffixes:
        if out.endswith(s):
            out = out[:-len(s)]
    return out

def zbx_resolve_device(query: str) -> dict:
    """
    Resolve by:
    - if IP: hostinterface.get filter ip -> host.get by hostid
    - else: host.get search host/name
    Returns: {hostid, ip, zbx_host, zbx_name, device_type}
    """
    q = (query or "").strip()

    if looks_like_ip(q):
        # hostinterface.get by IP
        res = zbx_call("hostinterface.get", {
            "output": ["hostid", "ip"],
            "filter": {"ip": q}
        })
        if not res:
            raise RuntimeError(f"لم أجد أي host يطابق IP '{q}' في Zabbix")

        hostid = res[0]["hostid"]
        h = zbx_call("host.get", {
            "output": ["host", "name"],
            "hostids": [hostid],
            "selectInterfaces": ["ip"]
        })
        if not h:
            raise RuntimeError(f"لم أجد hostid={hostid} بعد hostinterface.get")

        h0 = h[0]
        ip = (h0.get("interfaces") or [{}])[0].get("ip", q)
        zbx_host = h0.get("host") or q
        zbx_name = h0.get("name") or zbx_host

    else:
        # host.get search
        res = zbx_call("host.get", {
            "output": ["host", "name", "hostid"],
            "search": {"host": q, "name": q},
            "searchByAny": True,
            "startSearch": True,
            "selectInterfaces": ["ip"]
        })

        if not res:
            # try exact filter
            res = zbx_call("host.get", {
                "output": ["host", "name", "hostid"],
                "filter": {"host": [q]},
                "selectInterfaces": ["ip"]
            })

        # fallback: try base hostname without suffix
        if not res:
            base_q = base_host_name(q)
            if base_q != q:
                res = zbx_call("host.get", {
                    "output": ["host", "name", "hostid"],
                    "search": {"host": base_q, "name": base_q},
                    "searchByAny": True,
                    "startSearch": True,
                    "selectInterfaces": ["ip"]
                })

        if not res:
            raise RuntimeError(f"لم أجد أي host يطابق '{q}' في Zabbix")

        # prefer host without suffix if found
        h0 = res[0]
        base_q = base_host_name(q)
        for h in res:
            if (h.get("host") or "") == base_q:
                h0 = h
                break

        hostid = h0["hostid"]
        zbx_host = h0.get("host") or q
        zbx_name = h0.get("name") or zbx_host

        ip = (h0.get("interfaces") or [{}])[0].get("ip")
        if not ip:
            ifs = zbx_call("hostinterface.get", {
                "output": ["ip"],
                "hostids": [hostid]
            })
            ip = ifs[0]["ip"] if ifs else None

        if not ip:
            raise RuntimeError(f"Host '{zbx_host}' لا يحتوي IP واضح في interfaces")

    # probe OS type with cache
    device_type = probe_os_type(ip, SSH_USER, SSH_PASS, SSH_PORT)

    return {
        "hostid": hostid,
        "ip": ip,
        "zbx_host": zbx_host,
        "zbx_name": zbx_name,
        "device_type": device_type,
    }
# ===================== OS TYPE CACHE =====================
def load_cache():
    try:
        with open(OS_CACHE_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}

def save_cache(cache):
    try:
        with open(OS_CACHE_FILE, "w") as f:
            json.dump(cache, f, indent=2)
    except Exception:
        pass

OS_TYPE_CACHE = load_cache()

def probe_os_type(ip: str, username: str, password: str, port: int = 22) -> str:
    """
    One SSH probe using show version.
    Cache result per IP.
    """
    if ip in OS_TYPE_CACHE:
        return OS_TYPE_CACHE[ip]

    dtype = "cisco_xe"
    try:
        conn = ConnectHandler(
            device_type="cisco_xr",  # probe driver
            host=ip,
            username=username,
            password=password,
            port=port,
            fast_cli=True,
            global_delay_factor=1,
            conn_timeout=10,
            banner_timeout=20,
            auth_timeout=20,
        )
        out = conn.send_command("show version", delay_factor=1, max_loops=1500) or ""
        conn.disconnect()

        u = out.upper()
        if "IOS XR" in u or "XR SOFTWARE" in u or "CISCO IOS XR" in u:
            dtype = "cisco_xr"
        else:
            dtype = "cisco_xe"
    except Exception:
        dtype = "cisco_xe"

    OS_TYPE_CACHE[ip] = dtype
    save_cache(OS_TYPE_CACHE)
    return dtype


# ===================== NETMIKO CONNECT =====================
def connect_device(dev: dict):
    return ConnectHandler(
        device_type=dev["device_type"],
        host=dev["ip"],
        username=SSH_USER,
        password=SSH_PASS,
        port=SSH_PORT,
        fast_cli=True,
        global_delay_factor=1,
        conn_timeout=15,
        banner_timeout=25,
        auth_timeout=25,
    )


# ===================== INTERFACE NORMALIZATION =====================
def base_name(name: str) -> str:
    name = (name or "").strip()
    if "-" in name:
        return "-".join(name.split("-")[:-1]) or name
    return name


def build_pairs_by_desc_nameonly(rowsA, rowsB, A_names, B_names):
    """
    Name-only matching:
    - Pick A ports whose desc contains any token from B_names
    - Pick B ports whose desc contains any token from A_names
    - Return pairs by order (or return lists if you prefer)
    """
    def hit(desc, tokens):
        dl = (desc or "").lower()
        return any(t.lower() in dl for t in tokens)

    a_hits = [(i, d) for (i, d) in rowsA if hit(d, B_names)]
    b_hits = [(i, d) for (i, d) in rowsB if hit(d, A_names)]

    # If nothing found
    if not a_hits or not b_hits:
        return []

    # Pair by order (best effort)ذ
    m = min(len(a_hits), len(b_hits))
    pairs = []
    for idx in range(m):
        a_intf, a_desc = a_hits[idx]
        b_intf, b_desc = b_hits[idx]
        pairs.append((a_intf, b_intf, a_desc, b_desc))
    return pairs

def normalize_intf(intf: str) -> str:
    x = (intf or "").strip()

    x = x.replace("HundredGigabitEthernet", "Hu")
    x = x.replace("HundredGigE", "Hu")

    x = x.replace("FortyGigabitEthernet", "Fo")
    x = x.replace("FortyGigE", "Fo")

    x = x.replace("TwentyFiveGigabitEthernet", "Twe")
    x = x.replace("TwentyFiveGigE", "Twe")

    x = x.replace("TenGigabitEthernet", "Te")
    x = x.replace("TenGigE", "Te")

    x = x.replace("GigabitEthernet", "Gi")
    x = x.replace("Ethernet", "Eth")

    x = re.sub(r"\s+", "", x)
    # remove subinterface if present
    x = re.sub(r"\.\d+$", "", x)
    return x

def to_xr_intf(intf: str) -> str:
    x = (intf or "").strip()
    x = re.sub(r"^Hu", "HundredGigE", x)
    x = re.sub(r"^Fo", "FortyGigE", x)
    x = re.sub(r"^Twe", "TwentyFiveGigE", x)
    x = re.sub(r"^Te", "TenGigE", x)
    x = re.sub(r"^Gi", "GigabitEthernet", x)
    return x


# ===================== DESCRIPTION MATCHING =====================
def build_match_names(dev: dict, user_query: str):
    """
    Use ONLY short site code:
    DNANJDC2-DisSw01  -> DNANJDC2
    RNANJF78-RpGwy01  -> RNANJF78
    """
    def short_name(s: str):
        s = (s or "").strip()
        if not s:
            return None
        # take only part before first '-'
        return s.split("-")[0]

    names = set()

    for v in [dev.get("zbx_host"), dev.get("zbx_name"), user_query]:
        sn = short_name(v)
        if sn and len(sn) >= 3:
            names.add(sn)

    return names

def get_int_descriptions(conn, keywords=None, device_type="cisco_xe"):
    """
    Get (intf, desc). If keywords provided, filter on device side for speed.
    Works on XE/XR using 'show interfaces description' plus include.
    """
    kw = [k for k in (keywords or []) if k]
    out = ""

    if kw:
        pat = "|".join(re.escape(k) for k in kw)
        # XR uses "include" often; XE supports "| i"
        cmds = [
            f"show interfaces description | i {pat}",
            f"show interfaces description | include {pat}",
        ]
    else:
        cmds = ["show interfaces description"]

    for cmd in cmds:
        try:
            out = conn.send_command(cmd, delay_factor=2, max_loops=3000) or ""
            if out.strip():
                break
        except Exception:
            continue

    rows = []
    for line in out.splitlines():
        parts = line.split()
        if len(parts) < 2:
            continue
        intf = normalize_intf(parts[0])

        # Heuristic: common formats: intf  status  protocol  description...
        if len(parts) >= 4 and parts[1].lower() in ("up","down","admin","administratively") or parts[2].lower() in ("up","down"):
            desc = " ".join(parts[3:])
        else:
            # fallback: everything after interface
            desc = " ".join(parts[1:])
        rows.append((intf, desc.strip()))

    return rows


def extract_remote_port_from_desc(desc: str):
    """
    Strong extractor: grabs any interface mention in messy description.
    Supports long and short forms with separators.
    """
    if not desc:
        return None

    d = desc.strip()

    # Long names: HundredGigE0/0/0/31  FortyGigE0/0/0/28  TwentyFiveGigE...
    m = re.search(
        r"(HundredGigE|FortyGigE|TwentyFiveGigE|TenGigE|GigabitEthernet|Ethernet)"
        r"\s*[/\-_:\(\)\[\]\s]*"
        r"(\d+(?:/\d+){2,3})"
        r"(?:\.\d+)?",
        d,
        flags=re.I
    )
    if m:
        return normalize_intf(m.group(1) + m.group(2))

    # Short forms: Hu0/0/0/31 Fo0/0/0/28 Twe1/0/1 Te1/0/1 Gi0/1
    m = re.search(
        r"\b(Hu|Fo|Twe|Te|Gi|Eth)"
        r"\s*[/\-_:\(\)\[\]\s]*"
        r"(\d+(?:/\d+){1,3})"
        r"(?:\.\d+)?\b",
        d,
        flags=re.I
    )
    if m:
        return normalize_intf(m.group(1) + m.group(2))

    return None


def build_pairs_by_desc(rowsA, rowsB, A_names, B_names):
    """
    Exact pairing requires:
      - A desc contains B token
      - A desc contains remote port (B intf)
      - B desc of that port contains A token
    """
    b_map = {b_intf: b_desc for (b_intf, b_desc) in rowsB}
    pairs = []

    for a_intf, a_desc in rowsA:
        a_desc_l = (a_desc or "").lower()
        if not any(n.lower() in a_desc_l for n in B_names):
            continue

        b_intf = extract_remote_port_from_desc(a_desc)
        if not b_intf:
            continue

        b_desc = b_map.get(b_intf)
        if not b_desc:
            continue

        if not any(n.lower() in (b_desc or "").lower() for n in A_names):
            continue

        pairs.append((a_intf, b_intf, a_desc, b_desc))

    return pairs


# ===================== LLDP FALLBACK =====================
def get_lldp_output(conn):
    cmds = [
        "show lldp neighbors detail",
        "show lldp neighbors",
    ]
    for cmd in cmds:
        try:
            out = conn.send_command(cmd, delay_factor=2, max_loops=3000) or ""
            if out.strip():
                return out
        except Exception:
            continue
    return ""


def parse_lldp_neighbors(text: str):
    """
    Tolerant parser (XE/XR). Returns list of:
      {local_intf, remote_name, remote_port}
    """
    t = (text or "").replace("\r", "")
    lines = [ln.rstrip() for ln in t.splitlines()]

    neighbors = []
    cur = {"local_intf": None, "remote_name": None, "remote_port": None}

    def flush():
        if cur["local_intf"] and cur["remote_name"]:
            neighbors.append(dict(cur))

    for ln in lines:
        s = ln.strip()

        m = re.search(r"\bLocal\s+(?:Intf|Interface)\s*:\s*([A-Za-z]+[\w/\.]+)", s, re.I)
        if m:
            flush()
            cur = {"local_intf": normalize_intf(m.group(1)), "remote_name": None, "remote_port": None}
            continue

        m = re.search(r"\bSystem\s+Name\s*:\s*(.+)$", s, re.I)
        if m:
            cur["remote_name"] = m.group(1).strip()
            continue

        m = re.search(r"\b(?:Device\s+ID|Chassis\s+id)\s*:\s*(.+)$", s, re.I)
        if m and not cur["remote_name"]:
            cur["remote_name"] = m.group(1).strip()
            continue

        m = re.search(r"\bPort\s+id\s*:\s*([A-Za-z]+[\w/\.]+)", s, re.I)
        if m:
            cur["remote_port"] = normalize_intf(m.group(1))
            continue

    flush()
    return neighbors
def lldp_map_a_to_b(connA, B_names):
    """
    Returns dict: {a_local_intf: b_remote_port}
    using only A-side LLDP details.
    """
    outA = get_lldp_output(connA)
    nA = parse_lldp_neighbors(outA)

    def name_hit(remote_name: str, tokens):
        rn = (remote_name or "").lower()
        return any(t.lower() in rn for t in tokens)

    mp = {}
    for nb in nA:
        if not name_hit(nb.get("remote_name"), B_names):
            continue
        a_local = nb.get("local_intf")
        b_remote = nb.get("remote_port")
        if a_local and b_remote:
            mp[a_local] = b_remote
    return mp

def lldp_pairs_between(connA, connB, A_names, B_names):
    """
    Correct LLDP pairing:
    - Use A's LLDP detail to map A_local_intf -> B_remote_port (Port ID)
    - That gives exact pair even when numbering differs (20 -> 22)
    """
    outA = get_lldp_output(connA)
    nA = parse_lldp_neighbors(outA)

    def name_hit(remote_name: str, tokens):
        rn = (remote_name or "").lower()
        return any(t.lower() in rn for t in tokens)

    pairs = []
    for nb in nA:
        if not name_hit(nb.get("remote_name"), B_names):
            continue

        a_local = nb.get("local_intf")
        b_remote = nb.get("remote_port")  # Port ID on the neighbor
        if not a_local or not b_remote:
            continue

        pairs.append(
            (a_local, b_remote,
             f"LLDP -> {nb.get('remote_name')} port {b_remote}",
             "LLDP (paired from A-side)")
        )

    return pairs

# ===================== OPTICS PARSERS =====================
def parse_xe_table_transceiver(text: str, intf_short: str):
    """
    Example:
    Port  Temp  Volt  Current  Tx Power  Rx Power
    Hu1/0/9  24.3  3.26  55.5   1.28    -11.96
    """
    t = (text or "").replace("\r", "")
    intf_short = normalize_intf(intf_short)
    tx = rx = None

    for line in t.splitlines():
        s = line.strip()
        if not s:
            continue

        # match row starting with interface
        if s.startswith(intf_short):
            # grab all floats in line; last two are usually Tx/Rx
            nums = re.findall(r"([-+]?\d+(?:\.\d+)?)", s)
            # Expect: temp, volt, current, tx, rx (5 nums) or more
            if len(nums) >= 2:
                try:
                    # take last two numbers as tx/rx
                    tx = float(nums[-2])
                    rx = float(nums[-1])
                    return {"tx_dbm": tx, "rx_dbm": rx}
                except Exception:
                    pass

        # sometimes interface not normalized in output (HundredGigE..)
        if normalize_intf(s.split()[0]) == intf_short:
            nums = re.findall(r"([-+]?\d+(?:\.\d+)?)", s)
            if len(nums) >= 2:
                try:
                    tx = float(nums[-2])
                    rx = float(nums[-1])
                    return {"tx_dbm": tx, "rx_dbm": rx}
                except Exception:
                    pass

    return {"tx_dbm": None, "rx_dbm": None}


def parse_xr_optics(text: str):
    """
    Prefer table "TX Power / RX Power" and ignore Thresholds.
    """
    t = (text or "").replace("\r", "")
    lines = [ln.strip() for ln in t.splitlines() if ln.strip()]

    # table header method
    for i, ln in enumerate(lines):
        u = ln.upper()
        if "TX POWER" in u and "RX POWER" in u:
            last = None
            for j in range(i + 1, min(i + 12, len(lines))):
                cand = lines[j]
                cu = cand.upper()
                if set(cand) <= set("-_ "):
                    continue
                if "THRESH" in cu or "ALARM" in cu or "WARNING" in cu:
                    continue
                nums = re.findall(r"([-+]?\d+(?:\.\d+)?)\s*dBm", cand, flags=re.I)
                if len(nums) >= 2:
                    try:
                        last = (float(nums[0]), float(nums[1]))
                    except Exception:
                        pass
            if last:
                return {"tx_dbm": last[0], "rx_dbm": last[1]}

    # fallback labeled lines (rare)
    tx = rx = None
    for ln in lines:
        u = ln.upper()
        if "THRESH" in u or "ALARM" in u or "WARNING" in u:
            continue
        m = re.search(r"\bTx\s*Power\b.*?([-+]?\d+(?:\.\d+)?)\s*dBm", ln, re.I)
        if m and tx is None:
            try: tx = float(m.group(1))
            except: pass
        m = re.search(r"\bRx\s*Power\b.*?([-+]?\d+(?:\.\d+)?)\s*dBm", ln, re.I)
        if m and rx is None:
            try: rx = float(m.group(1))
            except: pass

    return {"tx_dbm": tx, "rx_dbm": rx}

def lldp_map_a_to_b(connA, B_names):
    """
    Returns dict: {a_local_intf: b_remote_port}
    using only A-side LLDP details.
    """
    outA = get_lldp_output(connA)
    nA = parse_lldp_neighbors(outA)

    def name_hit(remote_name: str, tokens):
        rn = (remote_name or "").lower()
        return any(t.lower() in rn for t in tokens)

    mp = {}
    for nb in nA:
        if not name_hit(nb.get("remote_name"), B_names):
            continue
        a_local = nb.get("local_intf")
        b_remote = nb.get("remote_port")
        if a_local and b_remote:
            mp[a_local] = b_remote
    return mp

def get_power_dbm(conn, intf: str, device_type: str):
    dt = (device_type or "").lower()
    intf_short = normalize_intf(intf)

    # IOS XR
    if "xr" in dt:
        xr_intf = to_xr_intf(intf_short)
        cmds = [
            f"show controllers optics {xr_intf}",
            f"show controllers {xr_intf} optics",
            f"show controllers {xr_intf} phy",
        ]
        for cmd in cmds:
            try:
                out = conn.send_command(cmd, delay_factor=2, max_loops=3000) or ""
            except Exception:
                out = ""
            p = parse_xr_optics(out)
            if p["tx_dbm"] is not None or p["rx_dbm"] is not None:
                return p
        return {"tx_dbm": None, "rx_dbm": None}

    # IOS / IOS-XE
    cmds = [
        f"show interface {intf_short} transceiver",
        f"show int {intf_short} transceiver",
        f"show interface {intf_short} transceiver detail",
    ]
    for cmd in cmds:
        try:
            out = conn.send_command(cmd, delay_factor=2, max_loops=3000) or ""
        except Exception:
            out = ""
        p = parse_xe_table_transceiver(out, intf_short)
        if p["tx_dbm"] is not None or p["rx_dbm"] is not None:
            return p

    return {"tx_dbm": None, "rx_dbm": None}


# ===================== TELEGRAM HANDLERS =====================
async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_chat.send_message(
        "✅ <b>Optics Bot Ready</b>\n\n"
        "📌 <b>Usage:</b>\n"
        "1️⃣ <code>HOSTA HOSTB</code>\n"
        "2️⃣ <code>HOSTA HOSTB KEYWORD</code>\n\n"
        "📌 <b>Example:</b>\n"
        "<code>DNANJDC2-DisSw01 RNANJF78-RpGwy01 RNANJF78</code>",
        disable_web_page_preview=True,
        parse_mode="HTML"
    )

def color_counter(val: int) -> str:
    try:
        val = int(val)
    except:
        val = 0
    if val == 0:
        return f"🟢 {val}"
    else:
        return f"🔴 {val}"
def color_status(is_down: bool) -> str:
    return "🔴 DOWN" if is_down else "🟢 UP"
def color_down(is_down: bool):
    return "🔴 DOWN" if is_down else "🟢 UP"

def color_tx(val):
    if val is None:
        return "NA"

    # ⚫ No light / admin-down
    if val <= -39:
        return f" 🔴 {val:.2f}"

    # 🔴 Critical: ﺄﻘﻟ ﻢﻧ -15
    if val < -14:
        return f" 🟡 {val:.2f}"

    # 🟡 Warning: ﻢﻧ -15 ﺈﻟﻯ -13 (ﺵﺎﻤﻟ)
    if -13 <= val <= -11:
        return f" 🟢 {val:.2f}"

    # 🟢 Good: ﺄﻌﻟﻯ ﻢﻧ -13
    return f"🟢 {val:.2f}"    
def color_rx(val):
    if val is None:
        return "NA"

    # ⚫ No light / admin-down
    if val <= -39:
        return f" 🔴 {val:.2f}"

    # 🔴 Critical: أقل من -15
    if val < -14:
        return f" 🟡 {val:.2f}"

    # 🟡 Warning: من -15 إلى -13 (شامل)
    if -13 <= val <= -11:
        return f" 🟢 {val:.2f}"

    # 🟢 Good: أعلى من -13
    return f"🟢 {val:.2f}"

def extract_remote_intf_from_desc(desc: str):
    """
    Try to extract remote interface from description text.
    Works for XR/XE strings like:
    '...TwentyFiveGigE0/0/0/22-BX'
    '...FortyGigE0/0/0/28-ER'
    '...HundredGigE0/0/0/31-LR'
    '...Hu1/0/6-LR'
    Returns normalized interface string or None.
    """
    if not desc:
        return None

    d = desc.strip()

    # Common patterns (order matters)
    patterns = [
        r"(TwentyFiveGigE\d+(?:/\d+){2,3})",
        r"(TwentyFiveGigabitEthernet\d+(?:/\d+){2,3})",
        r"(FortyGigE\d+(?:/\d+){2,3})",
        r"(HundredGigE\d+(?:/\d+){2,3})",
        r"(TenGigE\d+(?:/\d+){2,3})",
        r"(GigabitEthernet\d+(?:/\d+){1,3})",
        r"(Te\d+(?:/\d+){2,3})",
        r"(Twe\d+(?:/\d+){2,3})",
        r"(Fo\d+(?:/\d+){2,3})",
        r"(Hu\d+(?:/\d+){2,3})",
        r"(TF\d+(?:/\d+){2,3})",
        r"(Gi\d+(?:/\d+){1,3})",
    ]

    found = []
    for pat in patterns:
        for m in re.finditer(pat, d, flags=re.I):
            found.append(m.group(1))

    if not found:
        return None

    raw = found[-1]  # ✅ take last match in desc

    # normalize long XR forms to short
    x = raw
    x = re.sub(r"^TwentyFiveGigabitEthernet", "Twe", x, flags=re.I)
    x = re.sub(r"^TwentyFiveGigE", "Twe", x, flags=re.I)
    x = re.sub(r"^FortyGigE", "Fo", x, flags=re.I)
    x = re.sub(r"^HundredGigE", "Hu", x, flags=re.I)
    x = re.sub(r"^TenGigE", "Te", x, flags=re.I)
    x = re.sub(r"^GigabitEthernet", "Gi", x, flags=re.I)

    return x

def clean_host(name: str):
    if not name:
        return ""
    return name.replace("-TTM", "").strip()


def parse_int_errors_common(output: str):
    """
    Returns: in_err, out_err, crc (ints or 0)
    Works for many XE/XR show interface outputs.
    """
    out = output or ""

    # XE often: "0 input errors, 0 CRC, 0 frame, 0 overrun, 0 ignored"
    m = re.search(r"(\d+)\s+input errors.*?(\d+)\s+CRC", out, re.I | re.S)
    if m:
        in_err = int(m.group(1))
        crc = int(m.group(2))
    else:
        # XR sometimes separate lines
        m_in = re.search(r"(\d+)\s+input errors", out, re.I)
        m_crc = re.search(r"(\d+)\s+crc", out, re.I)
        in_err = int(m_in.group(1)) if m_in else 0
        crc = int(m_crc.group(1)) if m_crc else 0

    # XE: "0 output errors, 0 collisions, 0 interface resets"
    m2 = re.search(r"(\d+)\s+output errors", out, re.I)
    out_err = int(m2.group(1)) if m2 else 0

    return in_err, out_err, crc


def get_intf_errors(conn, intf: str, device_type: str):
    """
    device_type: 'cisco_xe' or 'cisco_xr'
    """
    if not intf:
        return {"in_err": 0, "out_err": 0, "crc": 0}

    # commands
    if device_type == "cisco_xr":
        cmd = f"show interface {intf}"
    else:
        cmd = f"show interfaces {intf}"

    try:
        out = conn.send_command(cmd)
    except Exception:
        return {"in_err": 0, "out_err": 0, "crc": 0}

    in_err, out_err, crc = parse_int_errors_common(out)
    return {"in_err": in_err, "out_err": out_err, "crc": crc}


def parse_ping_xe(output: str):
    """
    XE ping usually: "Success rate is 100 percent (5/5), round-trip min/avg/max = 1/2/3 ms"
    """
    out = output or ""
    m1 = re.search(r"Success rate is\s+(\d+)\s+percent", out, re.I)
    success = int(m1.group(1)) if m1 else 0

    m2 = re.search(r"min/avg/max\s*=\s*(\d+)/(\d+)/(\d+)\s*ms", out, re.I)
    avg = int(m2.group(2)) if m2 else None
    return success, avg


def parse_ping_xr(output: str):
    """
    XR ping: often has "Success rate is 100 percent (5/5), round-trip min/avg/max = ..."
    sometimes different wording, so keep same parse
    """
    return parse_ping_xe(output)


def do_ping(conn, target_ip: str, device_type: str, count: int = 5):
    if not target_ip:
        return {"success": 0, "avg_ms": None}

    if device_type == "cisco_xr":
        cmd = f"ping {target_ip} count {count}"
    else:
        cmd = f"ping {target_ip} repeat {count}"

    try:
        out = conn.send_command(cmd)
    except Exception:
        return {"success": 0, "avg_ms": None}

    if device_type == "cisco_xr":
        success, avg = parse_ping_xr(out)
    else:
        success, avg = parse_ping_xe(out)

    return {"success": success, "avg_ms": avg}

def ping_between(conn, src_ip, dst_ip):
    """
    Runs ping from device to target IP.
    Returns: {"avg": int|None, "success": int|None}
    """
    try:
        # Cisco XE / XR compatible
        out = conn.send_command(f"ping {dst_ip} repeat 5", expect_string=r"#", strip_prompt=False)

        # success rate
        success = None
        m = re.search(r"Success +rate +is +(\d+) percent", out)
        if m:
            success = int(m.group(1))

        # avg RTT
        avg = None
        m = re.search(r"round-trip min/avg/max = \d+/(\d+)/\d+ ms", out)
        if m:
            avg = int(m.group(1))

        return {
            "avg": avg if avg is not None else 0,
            "success": success if success is not None else 0
        }

    except Exception:
        return {"avg": 0, "success": 0}

def get_int_errors(conn, intf: str):
    """
    Returns interface counters: in/out errors + crc
    Works for IOS-XE and IOS-XR
    """
    try:
        cmd = f"show interfaces {intf}"
        out = conn.send_command(cmd, read_timeout=30)

        # defaults
        res = {"in": 0, "out": 0, "crc": 0}

        for line in out.splitlines():
            l = line.lower()

            # IOS-XE / XR common patterns
            if "input errors" in l:
                # example: "0 input errors, 0 CRC, 0 frame..."
                parts = l.replace(",", "").split()
                res["in"] = int(parts[0])
                if "crc" in parts:
                    res["crc"] = int(parts[parts.index("crc") - 1])

            if "output errors" in l:
                # example: "0 output errors, 0 collisions..."
                parts = l.replace(",", "").split()
                res["out"] = int(parts[0])

        return res

    except Exception:
        return {"in": 0, "out": 0, "crc": 0}


def get_int_state(conn, intf: str, device_type: str):
    """
    Returns: (is_up: bool, note: str)
    """
    if not intf:
        return False, "no-intf"

    cmd = f"show interface {intf}"
    out = conn.send_command(cmd) or ""
    o = out.lower()

    # Common cases
    if "administratively down" in o:
        return False, "admin-down"

    # IOS-XE typical: "<Intf> is up, line protocol is up"
    if "line protocol is down" in o:
        return False, "line-down"

    # IOS-XR typical: "line state is up" / "line state is down"
    if "line state is down" in o:
        return False, "line-down"

    # If we can detect "is up" or "line protocol is up" or "line state is up"
    if " line protocol is up" in o or "line state is up" in o:
        return True, "up"

    # fallback (sometimes XR output differs)
    if re.search(r"\bis up\b", o) and ("line protocol" in o or "line state" in o):
        if "down" not in o:
            return True, "up"

    return True, "unknown"


def title_block(text: str):
    return [
        "━━━━━━━━━━━━━━━━━━━━━━",
        f"📊 {text}",
        "━━━━━━━━━━━━━━━━━━━━━━"
    ]

def section_block(text: str):
    return [
        "",
        f"📌 {text}",
        "──────────────────────"
    ]

def fmt_ping(label, ping):
    if not ping or ping.get("success", 0) == 0:
        return ""   # لا نطبع ping
    return f" ping->{label}:{ping['avg']}ms/{ping['success']}%"

def clean_name(name: str) -> str:
    if not name:
        return name
    for junk in ("-TTM", "-Test", "-TEST", "-test"):
        name = name.replace(junk, "")
    return name
def flag_optics_power(p, health_flags):
    rx = p.get("rx_dbm")
    tx = p.get("tx_dbm")

    # RX
    if rx is None:
        # خليها INFO مو WARNING حتى ما يگلك اسأل النوك بس لأن NA (اختياري)
        mark_info(health_flags, "RX NA")
    else:
        if rx <= -39:
            mark_crit(health_flags, f"RX critical ({rx} dBm)")
        elif rx < -14:
            mark_warn(health_flags, f"RX warning ({rx} dBm)")

    # TX (اختياري حسب حدودك)
    if tx is None:
        mark_info(health_flags, "TX NA")
    else:
        if tx < -10:
            mark_crit(health_flags, f"TX critical ({tx} dBm)")
        elif tx < -5:
            mark_warn(health_flags, f"TX warning ({tx} dBm)")


def ts_days_ago(days):
    return int(time.time()) - days * 86400

def normalize_zbx_text(s: str):
    s = (s or "").lower().strip()

    # long -> short
    s = s.replace("hundredgigabitethernet", "hu")
    s = s.replace("hundredgige", "hu")

    s = s.replace("fortygigabitethernet", "fo")
    s = s.replace("fortygige", "fo")

    s = s.replace("twentyfivegigabitethernet", "twe")
    s = s.replace("twentyfivegige", "twe")

    s = s.replace("tengigabitethernet", "te")
    s = s.replace("tengige", "te")

    s = s.replace("gigabitethernet", "gi")
    s = s.replace("ethernet", "eth")

    # short alias fixes
    s = s.replace("tf", "twe")   # مهم جداً
    # إذا عندك platform يعتبر TF = FortyGig
    # هذا يوحّد TF0/0/0/26 مع FortyGigE0/0/0/26

    s = s.replace("interface", "")
    s = s.replace(" ", "")
    s = s.replace("-", "")
    s = s.replace("_", "")
    s = s.replace(":", "")

    return s
def intf_aliases(intf: str):
    """
    Generate many possible aliases for one interface to match Zabbix item names.
    Example:
      Hu0/0/0/29
      HundredGigE0/0/0/29
      HundredGigabitEthernet0/0/0/29
    """
    if not intf:
        return []

    x = str(intf).strip()
    x = re.sub(r"\.\d+$", "", x)   # remove subinterface if present

    aliases = {x}

    # short -> long
    aliases.add(re.sub(r"^Hu", "HundredGigE", x, flags=re.I))
    aliases.add(re.sub(r"^Hu", "HundredGigabitEthernet", x, flags=re.I))

    aliases.add(re.sub(r"^Fo", "FortyGigE", x, flags=re.I))
    aliases.add(re.sub(r"^Fo", "FortyGigabitEthernet", x, flags=re.I))

    aliases.add(re.sub(r"^Twe", "TwentyFiveGigE", x, flags=re.I))
    aliases.add(re.sub(r"^Twe", "TwentyFiveGigabitEthernet", x, flags=re.I))

    aliases.add(re.sub(r"^Te", "TenGigE", x, flags=re.I))
    aliases.add(re.sub(r"^Te", "TenGigabitEthernet", x, flags=re.I))

    aliases.add(re.sub(r"^Gi", "GigabitEthernet", x, flags=re.I))
    aliases.add(re.sub(r"^Eth", "Ethernet", x, flags=re.I))

    # long -> short
    aliases.add(re.sub(r"^HundredGigabitEthernet", "Hu", x, flags=re.I))
    aliases.add(re.sub(r"^HundredGigE", "Hu", x, flags=re.I))

    aliases.add(re.sub(r"^FortyGigabitEthernet", "Fo", x, flags=re.I))
    aliases.add(re.sub(r"^FortyGigE", "Fo", x, flags=re.I))

    aliases.add(re.sub(r"^TwentyFiveGigabitEthernet", "Twe", x, flags=re.I))
    aliases.add(re.sub(r"^TwentyFiveGigE", "Twe", x, flags=re.I))

    aliases.add(re.sub(r"^TenGigabitEthernet", "Te", x, flags=re.I))
    aliases.add(re.sub(r"^TenGigE", "Te", x, flags=re.I))

    aliases.add(re.sub(r"^GigabitEthernet", "Gi", x, flags=re.I))
    aliases.add(re.sub(r"^Ethernet", "Eth", x, flags=re.I))

    # normalized copies
    norm_aliases = set()
    for a in aliases:
        norm_aliases.add(a)
        norm_aliases.add(normalize_zbx_text(a))

    return [a for a in norm_aliases if a]

def zbx_find_power_item(hostid, intf, power_type):
    if not intf or intf == "UNKNOWN":
        return None

    intf_norm = normalize_zbx_text(intf)
    cache_key = (hostid, intf_norm, power_type)
    if cache_key in ZBX_ITEM_CACHE:
        return ZBX_ITEM_CACHE[cache_key]

    items = zbx_call("item.get", {
        "output": ["itemid", "name", "key_", "lastvalue", "lastclock", "value_type"],
        "hostids": [hostid],
        "sortfield": "name"
    })

    best_main = None
    best_main_score = -999
    best_lane = None
    best_lane_score = -999

    if DEBUG_ZBX:
        print(f"[ZBX FIND] hostid={hostid} intf={intf} type={power_type} total_items={len(items)}")

    for it in items:
        name = (it.get("name") or "")
        key_ = (it.get("key_") or "")
        blob = f"{name} {key_}".lower()
        blob_norm = normalize_zbx_text(blob)

        if intf_norm not in blob_norm:
            continue
        if "power" not in blob:
            continue

        score = 0
        is_lane = "lane" in blob

        if power_type == "rx":
            if "receive power sensor" in blob:
                score += 100
            elif "rx power sensor" in blob:
                score += 80
            elif "receive power" in blob:
                score += 70
            elif "rx power" in blob:
                score += 60
            if not (("receive" in blob) or ("rx" in blob)):
                continue

        elif power_type == "tx":
            if "transmit power sensor" in blob:
                score += 100
            elif "tx power sensor" in blob:
                score += 80
            elif "transmit power" in blob:
                score += 70
            elif "tx power" in blob:
                score += 60
            if not (("transmit" in blob) or ("tx" in blob)):
                continue
        else:
            return None

        if str(it.get("lastvalue", "")).strip() not in ("", "None"):
            score += 5
        if str(it.get("lastclock", "")).strip() not in ("", "0", "None"):
            score += 5

        if is_lane:
            score -= 40
            if DEBUG_ZBX:
                print(f"[ZBX LANE CANDIDATE] {name} | score={score}")
            if score > best_lane_score:
                best_lane_score = score
                best_lane = it
        else:
            if DEBUG_ZBX:
                print(f"[ZBX MAIN CANDIDATE] {name} | score={score}")
            if score > best_main_score:
                best_main_score = score
                best_main = it

    if best_main:
        if DEBUG_ZBX:
            print(f"[ZBX BEST MAIN {power_type.upper()}] itemid={best_main['itemid']} name={best_main['name']} score={best_main_score}")
        ZBX_ITEM_CACHE[cache_key] = best_main["itemid"]
        return best_main["itemid"]

    if best_lane:
        if DEBUG_ZBX:
            print(f"[ZBX BEST LANE {power_type.upper()}] itemid={best_lane['itemid']} name={best_lane['name']} score={best_lane_score}")
        ZBX_ITEM_CACHE[cache_key] = best_lane["itemid"]
        return best_lane["itemid"]

    if DEBUG_ZBX:
        print(f"[ZBX MISS] hostid={hostid} intf={intf} type={power_type}")
    ZBX_ITEM_CACHE[cache_key] = None
    return None


def zbx_get_value_7d(itemid):
    if not itemid:
        return None
    if itemid in ZBX_7D_CACHE:
        return ZBX_7D_CACHE[itemid]

    now = datetime.now()
    week_day = now - timedelta(days=7)
    start = week_day.replace(hour=0, minute=0, second=0, microsecond=0)
    end = week_day.replace(hour=23, minute=59, second=59, microsecond=0)

    time_from = int(start.timestamp())
    time_till = int(end.timestamp())

    if DEBUG_ZBX:
        print(f"[ZBX GET 7D] itemid={itemid} from={time_from} till={time_till}")

    try:
        tr = zbx_call("trend.get", {
            "output": ["clock", "value_avg"],
            "itemids": [itemid],
            "time_from": time_from,
            "time_till": time_till,
            "sortfield": "clock",
            "sortorder": "DESC",
            "limit": 1
        })
        if DEBUG_ZBX:
            print(f"[ZBX TREND] itemid={itemid} rows={len(tr or [])}")
        if tr:
            ZBX_7D_CACHE[itemid] = float(tr[0]["value_avg"])
            return ZBX_7D_CACHE[itemid]
    except Exception as e:
        if DEBUG_ZBX:
            print(f"[ZBX TREND FAIL] itemid={itemid} err={e}")

    try:
        hs = zbx_call("history.get", {
            "output": ["clock", "value"],
            "history": 0,
            "itemids": [itemid],
            "time_from": time_from,
            "time_till": time_till,
            "sortfield": "clock",
            "sortorder": "DESC",
            "limit": 1
        })
        if DEBUG_ZBX:
            print(f"[ZBX HIST0] itemid={itemid} rows={len(hs or [])}")
        if hs:
            ZBX_7D_CACHE[itemid] = float(hs[0]["value"])
            return ZBX_7D_CACHE[itemid]
    except Exception as e:
        if DEBUG_ZBX:
            print(f"[ZBX HIST0 FAIL] itemid={itemid} err={e}")

    try:
        hs = zbx_call("history.get", {
            "output": ["clock", "value"],
            "history": 3,
            "itemids": [itemid],
            "time_from": time_from,
            "time_till": time_till,
            "sortfield": "clock",
            "sortorder": "DESC",
            "limit": 1
        })
        if DEBUG_ZBX:
            print(f"[ZBX HIST3] itemid={itemid} rows={len(hs or [])}")
        if hs:
            ZBX_7D_CACHE[itemid] = float(hs[0]["value"])
            return ZBX_7D_CACHE[itemid]
    except Exception as e:
        if DEBUG_ZBX:
            print(f"[ZBX HIST3 FAIL] itemid={itemid} err={e}")

    ZBX_7D_CACHE[itemid] = None
    return None
async def shut_port(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        args = context.args
        if len(args) < 2:
            await update.message.reply_text("Usage: /shut HOST INTERFACE")
            return

        host = args[0]
        intf = args[1]

        dev = zbx_resolve_device(host)
        conn = connect_device(dev)

        try:
            conn.enable()
        except:
            pass

        conn.send_config_set([
            f"interface {intf}",
            "shutdown",
            "commit"
        ])

        conn.disconnect()

        await update.message.reply_text(f"🔴 Shutdown done: {host} {intf}")

    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")




async def no_shut_port(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        args = context.args
        if len(args) < 2:
            await update.message.reply_text("Usage: /noshut HOST INTERFACE")
            return

        host = args[0]
        intf = args[1]

        dev = zbx_resolve_device(host)
        conn = connect_device(dev)

        try:
            conn.enable()
        except:
            pass

        conn.send_config_set([
            f"interface {intf}",
            "no shutdown",
            "commit"
        ])

        conn.disconnect()

        await update.message.reply_text(f"🟢 No shutdown done: {host} {intf}")

    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")
def zbx_port_power_7d(host, intf):
    if not intf or intf == "UNKNOWN":
        return {"rx_7d": None, "tx_7d": None}

    hostid = host["hostid"]
    host_name = host.get("zbx_host") or host.get("zbx_name") or str(hostid)

    if DEBUG_ZBX:
        print(f"\n[ZBX DEBUG] host={host_name} hostid={hostid} intf={intf}")

    rx_item = zbx_find_power_item(hostid, intf, "rx")
    tx_item = zbx_find_power_item(hostid, intf, "tx")

    rx_val = zbx_get_value_7d(rx_item) if rx_item else None
    tx_val = zbx_get_value_7d(tx_item) if tx_item else None

    if DEBUG_ZBX:
        print(f"[ZBX 7D] host={host_name} intf={intf} rx={rx_val} tx={tx_val}")

    return {
        "rx_7d": rx_val,
        "tx_7d": tx_val
    }

def fmt_compare(now, old):
    if now is None and old is None:
        return "NA(now+7d)"
    if now is None:
        return "NA(now)"
    if old is None:
        return "NA(7d)"

    diff = now - old
    return f"{old:.2f} ➜ {now:.2f} ({diff:+.2f})"

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    async def send(txt: str):
        await update.effective_chat.send_message(
            txt,
            disable_web_page_preview=True
        )

    user_text = (update.message.text or "").strip()
    if not user_text:
        return

    t = user_text
    t = re.sub(r"\s+[-–—]\s+", " ", t)
    t = re.sub(r"[,\|/&]+", " ", t).strip()
    parts = [p for p in t.split() if p]

    if len(parts) < 2:
        return

    a_query, b_query = parts[0], parts[1]
    filter_words = [w for w in parts[2:] if w and not re.search(r"[^\x00-\x7F]", w)]

    if not (is_valid_host(a_query) and is_valid_host(b_query)):
        return

    try:
        A, B = await resolve_both(a_query, b_query)
    except Exception as e:
        await send(f"❌ Resolve error:\n{str(e)[:1500]}")
        return

    if A["ip"] == B["ip"]:
        await send("⚠️ نفس الجهاز (نفس IP). لازم جهازين مختلفين.")
        return

    await send(
        f"✅ Resolved:\n"
        f"A: {A['zbx_host']} ({A['ip']}) type={A['device_type']}\n"
        f"B: {B['zbx_host']} ({B['ip']}) type={B['device_type']}"
        + (f"\n🔑 filter: {' '.join(filter_words)}" if filter_words else "")
    )

    connA = connB = None
    try:
        connA, connB = await connect_both(A, B)

        try:
            connA.enable()
        except Exception:
            pass
        try:
            connB.enable()
        except Exception:
            pass

        A_names = build_match_names(A, a_query)
        B_names = build_match_names(B, b_query)

        kwA = list(B_names)
        kwB = list(A_names)
        if filter_words:
            kwA.extend(filter_words)
            kwB.extend(filter_words)

        rowsA, rowsB = await get_desc_both(connA, kwA, A["device_type"], connB, kwB, B["device_type"])

        def desc_hit(desc, tokens):
            dl = (desc or "").lower()
            return any(t.lower() in dl for t in tokens)

        a_desc_ports = [(i, d) for (i, d) in rowsA if desc_hit(d, B_names)]
        a_desc_ports = [(i, d) for (i, d) in a_desc_ports if not i.upper().startswith(("BE", "PO", "BUNDLE"))]

        lldp_map = lldp_map_a_to_b(connA, B_names)

        pairs = []
        for a_intf, a_desc in a_desc_ports:
            b_intf = lldp_map.get(a_intf)
            if b_intf:
                if b_intf.upper().startswith(("BE", "PO", "BUNDLE")):
                    continue
                pairs.append((a_intf, b_intf, a_desc, "LLDP paired"))
            else:
                pairs.append((a_intf, None, a_desc, "DESC only (LLDP down)"))

        if not pairs:
            pairs = lldp_pairs_between(connA, connB, A_names=A_names, B_names=B_names)

        if filter_words and pairs:
            fw = [w.lower() for w in filter_words]

            def match_filter(a_desc: str, b_desc: str):
                blob = ((a_desc or "") + " " + (b_desc or "")).lower()
                return all(w in blob for w in fw)

            pairs = [(ai, bi, ad, bd) for (ai, bi, ad, bd) in pairs if match_filter(ad, bd)]

        if not pairs:
            return

        lines = []
        lines += title_block("Optics TX/RX Power (dBm)")
        lines.append("🔗 Physical Pairing (LLDP)")
        lines.append("──────────────────────")

        health_flags = build_health_flags()
        A_name = clean_name(A.get("zbx_host") or A.get("zbx_name") or A.get("host") or "A")
        B_name = clean_name(B.get("zbx_host") or B.get("zbx_name") or B.get("host") or "B")
        A_ip = A.get("ip")
        B_ip = B.get("ip")

        valid_pairs = []
        for a_intf, b_intf, a_desc, b_desc in pairs:
            if a_intf.upper().startswith(("BE", "PO", "BUNDLE")):
                continue
            if b_intf and b_intf.upper().startswith(("BE", "PO", "BUNDLE")):
                continue
            remote_guess = None
            from_desc = False
            if not b_intf:
                remote_guess = extract_remote_intf_from_desc(a_desc)
                if remote_guess:
                    from_desc = True
            b_intf_real = b_intf or remote_guess or "UNKNOWN"
            valid_pairs.append((a_intf, b_intf_real, a_desc, b_desc, from_desc))

        for a_intf, b_intf_real, a_desc, b_desc, from_desc in valid_pairs:
            pA = get_power_dbm(connA, a_intf, device_type=A["device_type"])
            pB = {"tx_dbm": None, "rx_dbm": None}
            if b_intf_real != "UNKNOWN":
                try:
                    pB = get_power_dbm(connB, b_intf_real, device_type=B["device_type"])
                except Exception:
                    pB = {"tx_dbm": None, "rx_dbm": None}

            flag_optics_power(pA, health_flags)
            flag_optics_power(pB, health_flags)

            zbxA, zbxB = await zbx_both(A, a_intf, B, b_intf_real)

            lines.append(f"A: {A_name}  {a_intf}  TX:{color_tx(pA['tx_dbm'])}  RX:{color_rx(pA['rx_dbm'])}")
            lines.append(f"B: {B_name}  {b_intf_real}{' (from desc)' if from_desc else ''}  TX:{color_tx(pB['tx_dbm'])}  RX:{color_rx(pB['rx_dbm'])}")

            lines.append(f"ZBX A RX 7d: {fmt_compare(pA['rx_dbm'], zbxA['rx_7d'])}" if zbxA["rx_7d"] is not None else "ZBX A RX 7d: no 7d data")
            lines.append(f"ZBX A TX 7d: {fmt_compare(pA['tx_dbm'], zbxA['tx_7d'])}" if zbxA["tx_7d"] is not None else "ZBX A TX 7d: no 7d data")
            lines.append(f"ZBX B RX 7d: {fmt_compare(pB['rx_dbm'], zbxB['rx_7d'])}" if zbxB["rx_7d"] is not None else "ZBX B RX 7d: no 7d data")
            lines.append(f"ZBX B TX 7d: {fmt_compare(pB['tx_dbm'], zbxB['tx_7d'])}" if zbxB["tx_7d"] is not None else "ZBX B TX 7d: no 7d data")
            lines.append("-" * 72)

            if pA["rx_dbm"] is None:
                health_flags["rx_na"] += 1
            elif pA["rx_dbm"] <= -39:
                health_flags["rx_crit"] += 1
                health_flags["all_green"] = False
            elif pA["rx_dbm"] < -15:
                health_flags["rx_warn"] += 1
                health_flags["all_green"] = False

            if pB["rx_dbm"] is None:
                health_flags["rx_na"] += 1
            elif pB["rx_dbm"] <= -39:
                health_flags["rx_crit"] += 1
                health_flags["all_green"] = False
            elif pB["rx_dbm"] < -15:
                health_flags["rx_warn"] += 1
                health_flags["all_green"] = False

        lines.append("")
        lines += section_block("Ping & Error Stats (CRC)")

        for a_intf, b_intf_real, a_desc, b_desc, from_desc in valid_pairs:
            a_up, a_note = get_int_state(connA, a_intf, A["device_type"])
            b_up, b_note = get_int_state(connB, b_intf_real, B["device_type"]) if b_intf_real != "UNKNOWN" else (False, "no-intf")

            if (not a_up) or (not b_up):
                pingA = {"avg": "NA", "success": 0}
                pingB = {"avg": "NA", "success": 0}
                errA = get_int_errors(connA, a_intf)
                errB = get_int_errors(connB, b_intf_real) if b_intf_real != "UNKNOWN" else {"in": 0, "out": 0, "crc": 0}

                a_is_down = "DOWN" in (a_desc or "").upper()
                b_is_down = "DOWN" in (b_desc or "").upper()

                lines.append(f"A: {A_name} {a_intf} ({color_down(a_is_down)}){fmt_ping('B', pingA)}")
                lines.append(f"B: {B_name} {b_intf_real} ({color_down(b_is_down)}){fmt_ping('A', pingB)}")
                lines.append("-" * 24)
                continue

            pingA = ping_between(connA, A_ip, B_ip)
            pingB = ping_between(connB, B_ip, A_ip)
            errA = get_int_errors(connA, a_intf)
            errB = get_int_errors(connB, b_intf_real) if b_intf_real != "UNKNOWN" else {"in": 0, "out": 0, "crc": 0}

            lines.append(f"A: {A_name} {a_intf} ping->B:{pingA['avg']}ms/{pingA['success']}% IN:{color_counter(errA['in'])} OUT:{color_counter(errA['out'])} CRC:{color_counter(errA['crc'])}")
            lines.append(f"B: {B_name} {b_intf_real} ping->A:{pingB['avg']}ms/{pingB['success']}% IN:{color_counter(errB['in'])} OUT:{color_counter(errB['out'])} CRC:{color_counter(errB['crc'])}")
            lines.append("-" * 72)

            try:
                if pingA.get("success", 100) < 100:
                    mark_warn(health_flags, f"Ping A->B {pingA.get('success')}%")
                if pingB.get("success", 100) < 100:
                    mark_warn(health_flags, f"Ping B->A {pingB.get('success')}%")
            except Exception:
                pass

            try:
                if errA.get("crc", 0) > 0:
                    mark_warn(health_flags, f"CRC A {errA.get('crc')}")
                if errB.get("crc", 0) > 0:
                    mark_warn(health_flags, f"CRC B {errB.get('crc')}")
                if errA.get("in", 0) > 0 or errA.get("out", 0) > 0:
                    mark_warn(health_flags, "Errors A")
                if errB.get("in", 0) > 0 or errB.get("out", 0) > 0:
                    mark_warn(health_flags, "Errors B")
            except Exception:
                pass

        summary_text = "\n".join(lines)
        lines += section_block("🤖 AI / Decision")
        lines.append(analyze_with_ai(summary_text, health_flags))

        msg = "```\n" + "\n".join(lines) + "\n```"
        await send(msg[:3900])

    except Exception as e:
        await send(f"❌ Runtime error:\n{str(e)[:1500]}")
    finally:
        try:
            if connA:
                connA.disconnect()
        except Exception:
            pass
        try:
            if connB:
                connB.disconnect()
        except Exception:
            pass

def main():
    app = Application.builder().token(TG_TOKEN).build()
    app.add_handler(CommandHandler("shut", shut_port))
    app.add_handler(CommandHandler("noshut", no_shut_port))
    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    print("✅ Bot running...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()

