AI Network Automation Tool (Cisco + Zabbix + Telegram)

Setup Instructions:

1. Install requirements:
pip install -r requirements.txt

2. Configure:
- Add your Telegram Bot Token
- Add your Cisco device credentials
- Add your Zabbix API details

3. Run:
python bot.py

Features:
- Interface monitoring
- RX/TX power analysis
- Zabbix historical comparison
- AI-powered insights

Contact:
For support or customization, contact me.